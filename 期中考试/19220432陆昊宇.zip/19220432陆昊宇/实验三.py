import cv2
import numpy as np

# 读取图像
image = cv2.imread('face.png')

# 转换到YCbCr颜色空间
ycrcb_image = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)

# 定义肤色范围（YCbCr）
lower_skin_ycrcb = np.array([0, 133, 77], dtype=np.uint8)
upper_skin_ycrcb = np.array([255, 173, 127], dtype=np.uint8)

# 创建肤色掩码
skin_mask_ycrcb = cv2.inRange(ycrcb_image, lower_skin_ycrcb, upper_skin_ycrcb)

# 提取肤色区域
skin_area = cv2.bitwise_and(image, image, mask=skin_mask_ycrcb)

# 增强肤色区域
hsv_skin_area = cv2.cvtColor(skin_area, cv2.COLOR_BGR2HSV)
hsv_skin_area[:, :, 1] = np.minimum(hsv_skin_area[:, :, 1] * 1.2, 255)  # 增加饱和度
hsv_skin_area[:, :, 2] = np.minimum(hsv_skin_area[:, :, 2] * 1.1, 255)  # 增加亮度
enhanced_skin_area = cv2.cvtColor(hsv_skin_area, cv2.COLOR_HSV2BGR)

# 创建非肤色区域
non_skin_mask = cv2.bitwise_not(skin_mask_ycrcb)
non_skin_area = cv2.bitwise_and(image, image, mask=non_skin_mask)

# 合成最终结果
final_result = cv2.add(enhanced_skin_area, non_skin_area)

# 保存结果图像
cv2.imwrite('output_ycbcr.jpg', final_result)
