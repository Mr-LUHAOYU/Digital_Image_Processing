import cv2
import numpy as np

# 读取低光图像
image = cv2.imread("low-light.png")

# 将图像转换为灰度
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 对灰度图像进行直方图均衡化
equ_image = cv2.equalizeHist(gray_image)

# 合并均衡化的灰度图像到原图像中
enhanced_image = cv2.cvtColor(equ_image, cv2.COLOR_GRAY2BGR)

# 对比度拉伸
alpha = 1.5  # 对比度控制
beta = 0     # 亮度控制
contrast_stretched = cv2.convertScaleAbs(enhanced_image, alpha=alpha, beta=beta)

# 保存增强后的图像
cv2.imwrite("enhanced_image.jpg", contrast_stretched)

# 显示原始和增强后的图像
cv2.imshow('Original Image', image)
cv2.imshow('Enhanced Image', contrast_stretched)
cv2.waitKey(0)
cv2.destroyAllWindows()
