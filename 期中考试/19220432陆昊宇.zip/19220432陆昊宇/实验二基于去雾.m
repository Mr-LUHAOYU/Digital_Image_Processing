clear
clc
close all

img=imread( 'low-light.png');
figure,imshow(uint8(img)), title('原始低照度图像');
img(:,:,1)=255-img(:,:,1);
img(:,:,2)=255-img(:,:,2);
img(:,:,3)=255-img(:,:,3);
sz=size(img);
w=sz(2);
h=sz(1);
%计算RGB取最小值后的图像dark_I
dark_I = zeros(h,w);
for y=1:h
    for x=1:w
        dark_I(y,x) = min(img(y,x,:));%计算每个像素点RGB中最小的值
    end
end

kenlRatio = .03;
krnlsz = floor(max([3, w*kenlRatio, h*kenlRatio]));
dark_I2 = minfilt2(dark_I, [krnlsz,krnlsz]);%最小值滤波
dark_I2(h,w)=0;
dark_I2=uint8(dark_I2);

dark_channel=double(dark_I2);
aa=dark_channel;
hh=floor(w*h*0.001);
bb=reshape(aa,1,[]);%将a转换为行向量
bb=sort(bb,'descend');%将b按从大到小顺序排列。
cc=find(bb>0,hh);%找到前4个大于0（非NaN）的数的位置
dd=bb(cc(hh));%找到第4大的数
ee=aa(find(aa>dd));%较大的前3个数
[mm,nn]=find(aa>dd);%较大的前3个数对应下标
AA=[ee mm nn];
bw=zeros(h,w);
num=length(find(aa>dd));
sum=0;
for y=1:h
    for x=1:w
        for k=1:num
            if y==AA(k,2) && x==AA(k,3) && dark_channel(y,x)==AA(k,1)
                bw(y,x)=255;
                sum=sum+AA(k,1);
            end
        end
    end
end
meandc=floor(sum/num);
minAtomsLight = 240;
A= min([minAtomsLight, meandc]);%计算大气光A
  
w0=2.5;
t=1-w0*(dark_channel/A);%计算透射率t
t0=0.1;
t=max(t,t0);
img_d = double(img);
J = zeros(h,w,3);
J(:,:,1) = (img_d(:,:,1) - (1-t)*A)./t;%计算去雾后的R通道
J(:,:,2) = (img_d(:,:,2) - (1-t)*A)./t;%计算去雾后的G通道
J(:,:,3) = (img_d(:,:,3) - (1-t)*A)./t;%计算去雾后的B通道
J=uint8(J);
J(:,:,1)=255-J(:,:,1);
J(:,:,2)=255-J(:,:,2);
J(:,:,3)=255-J(:,:,3);
figure(2),imshow(J), title('基于暗原色先验的低照度图像增强J');%去雾图像
imwrite(J,'ans.jpg');


